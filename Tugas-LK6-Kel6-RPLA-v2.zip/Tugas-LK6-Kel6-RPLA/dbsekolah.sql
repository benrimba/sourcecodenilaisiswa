-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 03, 2020 at 11:51 AM
-- Server version: 5.7.17-log
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbsekolah`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbjurusan`
--

CREATE TABLE `tbjurusan` (
  `kdjur` varchar(20) NOT NULL,
  `jurusan` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbjurusan`
--

INSERT INTO `tbjurusan` (`kdjur`, `jurusan`) VALUES
('RPL', 'Rekasa Perangkat Lunak');

-- --------------------------------------------------------

--
-- Table structure for table `tbkelas`
--

CREATE TABLE `tbkelas` (
  `kdkls` varchar(20) NOT NULL,
  `kelas` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbkelas`
--

INSERT INTO `tbkelas` (`kdkls`, `kelas`) VALUES
('XMMA', 'X-MM-A'),
('XRPLA', 'X-RPL-A');

-- --------------------------------------------------------

--
-- Table structure for table `tbmapel`
--

CREATE TABLE `tbmapel` (
  `kdmapel` varchar(20) NOT NULL,
  `mapel` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbmapel`
--

INSERT INTO `tbmapel` (`kdmapel`, `mapel`) VALUES
('DB', 'Data Base'),
('PBO', 'Pemrograman Berorientasi Object');

-- --------------------------------------------------------

--
-- Table structure for table `tbnilai`
--

CREATE TABLE `tbnilai` (
  `idnilai` int(11) NOT NULL,
  `nis` varchar(20) NOT NULL,
  `idmapel` varchar(20) NOT NULL,
  `kdkls` varchar(20) NOT NULL,
  `kdjurn` varchar(20) NOT NULL,
  `uts` double NOT NULL,
  `uas` double NOT NULL,
  `uh` double NOT NULL,
  `na` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbnilai`
--

INSERT INTO `tbnilai` (`idnilai`, `nis`, `idmapel`, `kdkls`, `kdjurn`, `uts`, `uas`, `uh`, `na`) VALUES
(4, '20201', 'DB', 'XMMA', 'RPL', 80, 80, 80, 80);

-- --------------------------------------------------------

--
-- Table structure for table `tbsiswa`
--

CREATE TABLE `tbsiswa` (
  `nis` varchar(20) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jk` enum('L','P') NOT NULL,
  `alamat` text NOT NULL,
  `phone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbsiswa`
--

INSERT INTO `tbsiswa` (`nis`, `nama`, `jk`, `alamat`, `phone`) VALUES
('20201', 'Rudi Hartono', 'L', 'Cibinong-Bogor', '097788688');

-- --------------------------------------------------------

--
-- Table structure for table `tbuser`
--

CREATE TABLE `tbuser` (
  `iduser` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `level` enum('siswa','guru','baak','kepsek') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbuser`
--

INSERT INTO `tbuser` (`iduser`, `username`, `password`, `level`) VALUES
(1, 'siswa1', '12', 'siswa'),
(2, 'baak', 'baak1', 'baak'),
(3, 'guru1', 'guru1', 'guru'),
(4, 'kepsek', 'kepsek', 'kepsek'),
(5, 'siswa2', '123', 'siswa'),
(9, '20201', '20201', 'siswa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbjurusan`
--
ALTER TABLE `tbjurusan`
  ADD PRIMARY KEY (`kdjur`);

--
-- Indexes for table `tbkelas`
--
ALTER TABLE `tbkelas`
  ADD PRIMARY KEY (`kdkls`);

--
-- Indexes for table `tbmapel`
--
ALTER TABLE `tbmapel`
  ADD PRIMARY KEY (`kdmapel`);

--
-- Indexes for table `tbnilai`
--
ALTER TABLE `tbnilai`
  ADD PRIMARY KEY (`idnilai`),
  ADD KEY `idmapel` (`idmapel`),
  ADD KEY `nis` (`nis`),
  ADD KEY `kdjurn` (`kdjurn`),
  ADD KEY `kdkls` (`kdkls`);

--
-- Indexes for table `tbsiswa`
--
ALTER TABLE `tbsiswa`
  ADD PRIMARY KEY (`nis`);

--
-- Indexes for table `tbuser`
--
ALTER TABLE `tbuser`
  ADD PRIMARY KEY (`iduser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbnilai`
--
ALTER TABLE `tbnilai`
  MODIFY `idnilai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbuser`
--
ALTER TABLE `tbuser`
  MODIFY `iduser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbnilai`
--
ALTER TABLE `tbnilai`
  ADD CONSTRAINT `tbnilai_ibfk_1` FOREIGN KEY (`idmapel`) REFERENCES `tbmapel` (`kdmapel`),
  ADD CONSTRAINT `tbnilai_ibfk_2` FOREIGN KEY (`nis`) REFERENCES `tbsiswa` (`nis`),
  ADD CONSTRAINT `tbnilai_ibfk_3` FOREIGN KEY (`kdjurn`) REFERENCES `tbjurusan` (`kdjur`),
  ADD CONSTRAINT `tbnilai_ibfk_4` FOREIGN KEY (`kdkls`) REFERENCES `tbkelas` (`kdkls`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
