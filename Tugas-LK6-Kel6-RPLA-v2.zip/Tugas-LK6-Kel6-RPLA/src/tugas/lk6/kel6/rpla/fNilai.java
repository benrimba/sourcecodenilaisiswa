/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas.lk6.kel6.rpla;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author BenRimba
 */
public class fNilai extends javax.swing.JInternalFrame {

private final Connection kon = conConfig.koneksi();
DefaultTableModel tm;
    /**
     * Creates new form fSiswa
     */
    public fNilai() {
        initComponents();
        pForm.enable(false);
        cbKELAS();
        cbJurusan();
        cbSiswa();
        cbMapel();
        refreshTable();
    }
   private void refreshTable(){
        tm = new DefaultTableModel(
            null,
            new Object[] { "NIS","NAMA","JK","KELAS","MAPEL","UTS","UAS","UH","NA" }
        );
        tSiswa.setModel(tm);
        tm.getDataVector().removeAllElements();
        
        try {
            PreparedStatement s = kon.prepareStatement("SELECT * FROM tbnilai a,tbsiswa b,tbkelas c,tbmapel d WHERE a.nis=b.nis AND a.kdkls=c.kdkls AND a.idmapel=d.kdmapel");
            ResultSet r = s.executeQuery();
            while(r.next()) {
                Object[] data = {
                    r.getString("nis"),
                    r.getString("nama"),
                    r.getString("jk"),
                    r.getString("kelas"),
                    r.getString("mapel"),
                    r.getString("uts"),
                    r.getString("uas"),
                    r.getString("uh"),
                    r.getString("na")
                        
                        
                };
                tm.addRow(data);
            }
        } catch(Exception e) {
            System.out.print("Terjadi kesalahan:\n" + e + "\n\n");
        }
    }

   public void simpan(){
      try{
       PreparedStatement ps = kon.prepareStatement("INSERT INTO tbnilai VALUE(?,?,?,?,?,?,?,?,?)");
       ps.setString(1,null);
       ps.setString(2, (String) cbNM.getSelectedItem());
       ps.setString(3, (String) cbMP.getSelectedItem());
       ps.setString(4,(String) ckKls.getSelectedItem());
       ps.setString(5,(String) cbJur.getSelectedItem());
       ps.setString(6, txtUTS.getText());
       ps.setString(7, txtUAS.getText());
       ps.setString(8, txtUH.getText());
       double UTS,UAS,UH;
        UTS = Double.parseDouble(txtUTS.getText());
        UAS = Double.parseDouble(txtUAS.getText());
        UH = Double.parseDouble(txtUH.getText());
       double NA = (UTS+UAS+UH)/3;
       ps.setDouble(9, NA);
       ps.executeUpdate();
       refreshTable();
      }catch(Exception e){
          JOptionPane.showMessageDialog(null, "Gagal"+e);
      }
   }
   public void cbKELAS(){
   try{
        PreparedStatement s = kon.prepareStatement("SELECT * FROM tbkelas");
        ResultSet r = s.executeQuery();
            while(r.next()) {
                ckKls.addItem(r.getString("kdkls"));
            }           
            
   }catch(Exception e){
   System.out.print(e);
   }
   }
   public void tampilKls()
    {
        try {
        Statement stt = kon.createStatement();
        String sql = "SELECT*FROM tbkelas WHERE kdkls='"+ckKls.getSelectedItem()+"'";  
        ResultSet res = stt.executeQuery(sql);        
        while(res.next()){
            txtKLS.setText(res.getString("kelas"));
        }
        res.close(); stt.close();
         
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }              
    }
   
   public void cbJurusan(){
   try{
        PreparedStatement s = kon.prepareStatement("SELECT * FROM tbjurusan");
        ResultSet r = s.executeQuery();
            while(r.next()) {
                cbJur.addItem(r.getString("kdjur"));
            }           
            
   }catch(Exception e){
   System.out.print(e);
   }
   }
   public void tampilJurusan()
    {
        try {
        Statement stt = kon.createStatement();
        String sql = "SELECT*FROM tbjurusan WHERE kdjur='"+cbJur.getSelectedItem()+"'";  
        ResultSet res = stt.executeQuery(sql);        
        while(res.next()){
            txtJUR.setText(res.getString("jurusan"));
        }
        res.close(); stt.close();
         
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }              
    }
    public void cbSiswa(){
   try{
        PreparedStatement s = kon.prepareStatement("SELECT * FROM tbsiswa");
        ResultSet r = s.executeQuery();
            while(r.next()) {
                cbNM.addItem(r.getString("nis"));
            }           
            
   }catch(Exception e){
   System.out.print(e);
   }
   }
   public void tampilSiswa()
    {
        try {
        Statement stt = kon.createStatement();
        String sql = "SELECT*FROM tbsiswa WHERE nis='"+cbNM.getSelectedItem()+"'";  
        ResultSet res = stt.executeQuery(sql);        
        while(res.next()){
            txtNM.setText(res.getString("nama"));
        }
        res.close(); stt.close();
         
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }              
    }
   public void cbMapel(){
   try{
        PreparedStatement s = kon.prepareStatement("SELECT * FROM tbmapel");
        ResultSet r = s.executeQuery();
            while(r.next()) {
                cbMP.addItem(r.getString("kdmapel"));
            }           
            
   }catch(Exception e){
   System.out.print(e);
   }
   }
   public void tampilMapel()
    {
        try {
        Statement stt = kon.createStatement();
        String sql = "SELECT*FROM tbmapel WHERE kdmapel='"+cbMP.getSelectedItem()+"'";  
        ResultSet res = stt.executeQuery(sql);        
        while(res.next()){
            txtMP.setText(res.getString("mapel"));
        }
        res.close(); stt.close();
         
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }              
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        panelForm = new javax.swing.JPanel();
        pForm = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtKLS = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtJUR = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        ckKls = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtUTS = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        cbJur = new javax.swing.JComboBox<>();
        cbNM = new javax.swing.JComboBox<>();
        txtNM = new javax.swing.JTextField();
        cbMP = new javax.swing.JComboBox<>();
        txtMP = new javax.swing.JTextField();
        txtUAS = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtUH = new javax.swing.JTextField();
        btnADD = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        btnDel = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tSiswa = new javax.swing.JTable();

        setClosable(true);

        jPanel1.setBackground(new java.awt.Color(0, 204, 204));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("FORM INPUT DATA SISWA");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(233, 233, 233))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        panelForm.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "INPUT DATA NILAI SISWA", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N

        pForm.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel2.setText("KELAS");

        jLabel3.setText("JURUSAN");

        jLabel4.setText("NAMA");

        ckKls.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ckKlsActionPerformed(evt);
            }
        });

        jLabel5.setText("MAPEL");

        jLabel6.setText("UTS");

        jLabel8.setText("UAS");

        cbJur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbJurActionPerformed(evt);
            }
        });

        cbNM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbNMActionPerformed(evt);
            }
        });

        cbMP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbMPActionPerformed(evt);
            }
        });

        jLabel9.setText("UH");

        btnADD.setText("Simpan");
        btnADD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnADDActionPerformed(evt);
            }
        });

        btnCancel.setText("Ubah");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        btnDel.setText("Hapus");
        btnDel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pFormLayout = new javax.swing.GroupLayout(pForm);
        pForm.setLayout(pFormLayout);
        pFormLayout.setHorizontalGroup(
            pFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pFormLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pFormLayout.createSequentialGroup()
                        .addGroup(pFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addGap(77, 77, 77)
                        .addGroup(pFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(ckKls, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbJur, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbNM, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtKLS, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(txtJUR)
                            .addComponent(txtNM)))
                    .addGroup(pFormLayout.createSequentialGroup()
                        .addComponent(btnADD, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnDel, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pFormLayout.createSequentialGroup()
                        .addGroup(pFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9))
                        .addGap(91, 91, 91)
                        .addGroup(pFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtUH, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtUAS, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtUTS, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pFormLayout.createSequentialGroup()
                                .addComponent(cbMP, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtMP, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pFormLayout.setVerticalGroup(
            pFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pFormLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtKLS, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ckKls, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(pFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtJUR, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbJur, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(pFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbNM, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNM, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(cbMP, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMP, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtUTS, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtUAS, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtUH, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(30, 30, 30)
                .addGroup(pFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnADD, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        tSiswa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tSiswa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tSiswaMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tSiswa);

        javax.swing.GroupLayout panelFormLayout = new javax.swing.GroupLayout(panelForm);
        panelForm.setLayout(panelFormLayout);
        panelFormLayout.setHorizontalGroup(
            panelFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFormLayout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(pForm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 632, Short.MAX_VALUE))
        );
        panelFormLayout.setVerticalGroup(
            panelFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFormLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pForm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(panelForm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelForm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
       public void hapus(){
       try {
            PreparedStatement ps = kon.prepareStatement("DELETE FROM tbsiswa WHERE nis=?");
            ps.setString(1, txtKLS.getText());
            ps.executeUpdate();
            refreshTable();
            txtKLS.setText("");
            txtJUR.setText("");
            txtUTS.setText("");
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal dihapus"+e);
        }
       }
    private void btnDelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelActionPerformed
        // TODO add your handling code here:
        hapus();
        
    }//GEN-LAST:event_btnDelActionPerformed

    private void btnADDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnADDActionPerformed
        // TODO add your handling code here:
         simpan();
    }//GEN-LAST:event_btnADDActionPerformed
    public void ubah(){
      try {
            PreparedStatement ps = kon.prepareStatement("UPDATE tbsiswa SET nama=?,jk=?,alamat=?,phone=? WHERE nis=?");
            ps.setString(1, txtJUR.getText());
            ps.setString(2, (String) ckKls.getSelectedItem());
            ps.setString(4, txtUTS.getText());
            ps.setString(5,txtKLS.getText());
            ps.executeUpdate();
            
            refreshTable();
            txtKLS.setText("");
            txtJUR.setText("");
            txtUTS.setText("");
        } catch(Exception e) {
            System.out.print("Gagal Di Rubah:\n" + e + "\n\n");
        }

    }
    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        // TODO add your handling code here:
        ubah();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void tSiswaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tSiswaMouseClicked
        // TODO add your handling code here:
        cbNM.setSelectedItem(tm.getValueAt(tSiswa.getSelectedRow(),0).toString());
        cbNM.setSelectedItem(tm.getValueAt(tSiswa.getSelectedRow(),1).toString());
        ckKls.setSelectedItem(tm.getValueAt(tSiswa.getSelectedRow(),2).toString());
        txtUTS.setText(tm.getValueAt(tSiswa.getSelectedRow(),4).toString());

    }//GEN-LAST:event_tSiswaMouseClicked

    private void ckKlsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ckKlsActionPerformed
        // TODO add your handling code here:
        tampilKls();
        
    }//GEN-LAST:event_ckKlsActionPerformed

    private void cbJurActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbJurActionPerformed
        // TODO add your handling code here:
        tampilJurusan();
    }//GEN-LAST:event_cbJurActionPerformed

    private void cbNMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbNMActionPerformed
        // TODO add your handling code here:
        tampilSiswa();
    }//GEN-LAST:event_cbNMActionPerformed

    private void cbMPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbMPActionPerformed
        // TODO add your handling code here:
        tampilMapel();
    }//GEN-LAST:event_cbMPActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnADD;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnDel;
    private javax.swing.JComboBox<String> cbJur;
    private javax.swing.JComboBox<String> cbMP;
    private javax.swing.JComboBox<String> cbNM;
    private javax.swing.JComboBox<String> ckKls;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel pForm;
    private javax.swing.JPanel panelForm;
    private javax.swing.JTable tSiswa;
    private javax.swing.JTextField txtJUR;
    private javax.swing.JTextField txtKLS;
    private javax.swing.JTextField txtMP;
    private javax.swing.JTextField txtNM;
    private javax.swing.JTextField txtUAS;
    private javax.swing.JTextField txtUH;
    private javax.swing.JTextField txtUTS;
    // End of variables declaration//GEN-END:variables
}
