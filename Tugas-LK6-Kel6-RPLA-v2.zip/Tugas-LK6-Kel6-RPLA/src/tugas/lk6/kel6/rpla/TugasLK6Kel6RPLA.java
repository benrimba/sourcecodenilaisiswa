/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas.lk6.kel6.rpla;

/**
 *
 * @author BenRimba
 */
public class TugasLK6Kel6RPLA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       fLoading load = new fLoading();
       load.setVisible(true);
       MainMenu main= new MainMenu();
      try{
          for(int i=0;i<=100;i++){
              Thread.sleep(40);
              load.lblLoad.setText(Integer.toString(i));
              load.proBar.setValue(i);
              if(i==100){
              load.setVisible(false);
              main.setVisible(true);
              }
          }
      }catch(Exception e){}
    }
    
}
