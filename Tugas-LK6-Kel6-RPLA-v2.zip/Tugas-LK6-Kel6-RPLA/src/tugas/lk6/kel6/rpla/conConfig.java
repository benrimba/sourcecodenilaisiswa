/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas.lk6.kel6.rpla;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author BenRimba
 */
public class conConfig {
   private static Connection con;
  public static Connection koneksi(){    
       if(con==null){
      try{
          Class.forName("com.mysql.jdbc.Driver");
          con = DriverManager.getConnection("jdbc:mysql://localhost/dbsekolah","root","");          
      }catch(Exception e){
          JOptionPane.showMessageDialog(null, "Terjadi Kesalahan didatabase"+e);
      }
    }
       return con;
  }
}
